package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.util.DBConnection;


public class ProductDAO implements IProductDAO{
	
	Logger logger=Logger.getRootLogger();
	
	public ProductDAO()
	{
	PropertyConfigurator.configure("resources/log4j.properties");
	
	}

	@Override
	public ProductBean getProductDetails(int productCode) throws IOException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		int queryResult=0;
	
		try
		{
			ProductBean productBean=new ProductBean();
			ps=connection.prepareStatement(QueryMapper.get_ProductDetails);
			ps.setInt(1,productCode);
			rs=ps.executeQuery();
		
			 if(rs==null)
				{
					logger.error("Data Cannot Be Fetched From Database !!!\n Please Try After Sometime. ");
				}
				
				else if(rs.next())
				{
					productBean.setProduct_name(rs.getString(2));
					productBean.setProduct_category(rs.getString(3));
					productBean.setProduct_description(rs.getString(4));
					productBean.setProduct_price(rs.getDouble(5));
					logger.info("Data Retrieved Successfully");
				}
			 return productBean;
		}
		catch(Exception se)
		{
			se.printStackTrace();
		}
		return null;
		
	
	}

	@Override
	public boolean insertSalesDetails(ProductBean product) throws IOException, SQLException {
		
		Connection connection= DBConnection.getConnection();
		
		PreparedStatement ps=null;
		
		ps=connection.prepareStatement(QueryMapper.insert_Details);
		ps.setInt(1,product.getProduct_code());
		ps.setInt(2,product.getProduct_quantity());
		ps.setDouble(3,product.getLine_total());
		
		int rs=ps.executeUpdate();
		if(rs==0)
		{
			logger.error("Error occured while inserting details");
			return false;
		}
		else
		{
			logger.info("Successfully inserted into sales table");
			return true;
		}
	}

}
