package com.capgemini.salesmanagement.dao;

public class QueryMapper {
	
	public static final String get_ProductDetails="select * from product where product_code= ? ";
	public static String insert_Details="insert into sales values(sales_id_seq.nextVal,?,?,sysdate,?)";

}
