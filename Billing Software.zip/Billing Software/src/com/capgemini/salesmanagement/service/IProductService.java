package com.capgemini.salesmanagement.service;

import java.io.IOException;
import java.sql.SQLException;

import com.capgemini.salesmanagement.bean.ProductBean;

public interface IProductService {
	
	ProductBean getProductDetails(int productCode) throws IOException;
	boolean insertSalesDetails(ProductBean product) throws IOException, SQLException;

}
