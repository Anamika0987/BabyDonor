package com.capgemini.salesmanagement.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.ProductDAO;

public class ProductService implements IProductService{

		ProductDAO productDao=new ProductDAO();
	@Override
	public ProductBean getProductDetails(int productCode) throws IOException {
		
		ProductBean productBean=new ProductBean();
		productBean=productDao.getProductDetails(productCode);
		return productBean;
	}

	@Override
	public boolean insertSalesDetails(ProductBean product) throws IOException, SQLException {
		
		boolean result=productDao.insertSalesDetails(product);
		if(result)
		{
			return true;
		}
		else
			return false;
	}

	public void validateDetails(ProductBean productBean) {
		
		ArrayList<String> validationErrors = new ArrayList<String>();
		
		if(!(isValidProductCode(productBean.getProduct_code())))
		{
			validationErrors.add("Please Check The Product Code");
		}
		
		if(!(isValidProductQuantity(productBean.getProduct_quantity())))
		{
			validationErrors.add("Please Enter Positive Number For Qunatity ");
		}
		
	}

	private boolean isValidProductQuantity(int product_quantity) {
		
		if(product_quantity > 0)
		{
			return true;
		}
		else
			return false;
		
	}

	private boolean isValidProductCode(int product_code) {
		
		if(product_code>1000)
		{
			return true;
		}
		else	
			return false;
	}

}
