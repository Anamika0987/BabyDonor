package com.capgemini.salesmanagement.ui;

import java.util.Scanner;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.service.IProductService;
import com.capgemini.salesmanagement.service.ProductService;


public class Client {

	static Scanner scanner=new Scanner(System.in);
	static IProductService iproductService=null;
	static ProductService productService=null;
 
	public static void main(String[] args) {
		
		ProductBean productBean = null;
		
		int option=0;
		
		while(true)
		{
			

			System.out.println();
			System.out.println();
			System.out.println("  Billing Software Application  ");
			System.out.println("__________________________________");
			System.out.println("1- Get Product Details By Product Code");
			System.out.println("2- Exit");
			System.out.println("__________________________________");
			System.out.println(" Select An Option ");
		
		
			try
			{
			
				option =scanner.nextInt();
				switch(option)
				{
				case 1: while(productBean==null)
						{
							productBean = getProductBeanDetails();
						}
						try
						{
							int code= productBean.getProduct_code();
							int quantity=productBean.getProduct_quantity();
							productService = new ProductService();
							productBean=productService.getProductDetails(code);
							double price=productBean.getProduct_price();
							double line_total=quantity*price;
							
							System.out.println("Product Name: "+productBean.getProduct_name());
							System.out.println("Product Category: "+productBean.getProduct_category());
							System.out.println("Product Description: "+productBean.getProduct_description());
							System.out.println("Product Price: "+productBean.getProduct_price());
							System.out.println("Quantity: "+quantity);
							System.out.println("Line Total(Rs): "+line_total);
							productBean.setLine_total(line_total);
							productBean.setProduct_quantity(quantity);
							
							boolean result=productService.insertSalesDetails(productBean);
							
							if(result)
							{
								System.out.println("Values inserted into sales table Successfully");
							}
							else
							{
								System.out.println("Error Occured While Inserting values into sales table");
							}
								
						}
						catch(Exception e)
						{
							System.out.println(e);
						}
			
							break;
							
				case 2: System.exit(0);
						break;
				default: System.out.println("Please Enter Valid Option");
		
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}

	}


	private static ProductBean getProductBeanDetails() {
		
		ProductBean productBean=new ProductBean();

		System.out.println("Enter the product code");
		productBean.setProduct_code(scanner.nextInt());
		System.out.println("Enter the quantity");
		productBean.setProduct_quantity(scanner.nextInt());
		
		productService = new ProductService();
		
		try
		{
			productService.validateDetails(productBean);
			return productBean;
		}
		catch(Exception e)
		{
			
		}
		
		return null;
	}
}