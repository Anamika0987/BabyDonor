package com.capgemini.xyz.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

import util.Dbconnection;

public class LoanDao implements ILoanDao {

	@Override
	public long insertCust(Customer cust) throws SQLException, ClassNotFoundException, IOException {
		Connection connection = Dbconnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet = null;
		long custId = 0;
		
		preparedStatement = connection.prepareStatement("insert into customer values(cust_seq.nextval,'Aamir','Pune','aamir@gmail.com',9878675445)");
		preparedStatement.setString(1, cust.getCustName());
		preparedStatement.setString(2, cust.getAddress());
		preparedStatement.setString(3, cust.getMail());
		//preparedStatement.setString(4, cust.get());
		preparedStatement.executeUpdate();
		
		preparedStatement1 = connection.prepareStatement("select cust_id from customer_table where cust_name=?");
		preparedStatement1.setString(1, cust.getCustName());
		resultSet = preparedStatement1.executeQuery();
		while(resultSet.next()) {
			custId = resultSet.getLong(1);
		}
		return custId;
	}
	
	@Override
	public Loan applyLoan(Loan loan) throws SQLException, ClassNotFoundException, IOException {
		Connection connection = Dbconnection.getConnection();
		PreparedStatement preparedStatement = null;
		PreparedStatement preparedStatement1 = null;
		ResultSet resultSet = null;
		Loan retLoan = new Loan();
		
		preparedStatement = connection.prepareStatement("insert into loan_table values(loan_seq.nextval,?,?,?)");
		preparedStatement.setDouble(1, loan.getLoanAmount());
		preparedStatement.setLong(2,loan.getCustId());
		preparedStatement.setInt(3, loan.getDuration());
		preparedStatement.executeUpdate();
		
		preparedStatement1 = connection.prepareStatement("select * from loan_table where cust_id=?");
		preparedStatement1.setLong(1, loan.getCustId());
		resultSet = preparedStatement1.executeQuery();
		while(resultSet.next()) {
			retLoan.setLoanId(resultSet.getLong(1));
			retLoan.setLoanAmount(resultSet.getDouble(2));
			retLoan.setCustId(resultSet.getLong(3));
			retLoan.setDuration(resultSet.getInt(4));
		}
		return retLoan;
	}

}
